<%= javascript_include_tag "mailers", "data-turbolinks-track" => true  %>
;
